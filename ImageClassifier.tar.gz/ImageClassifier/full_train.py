

from time import time

from collections import OrderedDict
from torch.optim import SGD
from matplotlib.ticker import FormatStrFormatter
from PIL import Image
from torch import __version__
from torch.utils.data import DataLoader



import json
import numpy as np
import matplotlib.pyplot as plt
import argparse
import os
import torchvision
import torch.nn.functional as F
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import argparse

from select_input_types import args_parser
from transformer import transformer
from train_model import train_model
from save_checkpoint import save_checkpoint




data_dir = 'flowers'
train_dir = data_dir + '/train'
valid_dir = data_dir + '/valid'
test_dir = data_dir + '/test'
    
    
    
    data_tr_transforms = transforms.Compose([transforms.RandomRotation(30),
                                     transforms.RandomResizedCrop(224),
                                     transforms.RandomHorizontalFlip(),
                                     transforms.ToTensor(),
                                     transforms.Normalize((0.485, 0.456, 0.406), 
                                                          (0.229, 0.224, 0.225))])

    data_va_transforms = transforms.Compose([transforms.Resize(255),
                                        transforms.CenterCrop(244),
                                        transforms.ToTensor(),
                                        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])

    data_te_transforms = transforms.Compose ([transforms.Resize(255),
                                         transforms.CenterCrop(244),
                                         transforms.ToTensor(),
                                         transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])

    # TODO: Load the datasets with ImageFolder
    image_datasets_tr = datasets.ImageFolder(train_dir, transform=data_tr_transforms)
    image_datasets_va = datasets.ImageFolder(valid_dir, transform=data_va_transforms)
    image_datasets_te = datasets.ImageFolder(test_dir, transform=data_te_transforms)

    # TODO: Using the image datasets and the trainforms, define the dataloaders
    dataloaders_tr = torch.utils.data.DataLoader(image_datasets_tr, batch_size=256, shuffle=True)
    dataloaders_va = torch.utils.data.DataLoader(image_datasets_va, batch_size=256, shuffle=False)
    dataloaders_te = torch.utils.data.DataLoader(image_datasets_te, batch_size=256, shuffle=False)
    
    trans = transformer()

    print("i am working")
    trained_model = train_model(trans, args.hidden_units1, args.hidden_units2, args.epochs, args.arch, args.lr) #args.gpu)
    
    
    save_checkpoint(trained_model, args.save_dir)
    
    print('Checkpoint Saved!')
    
    
    end_time = time

    tot_time = end_time - start_time  #calculate difference between end time and start time
    
    print('Total time taken is:', tot_time)
    
    

    
    
    print("\n** Total Elapsed Runtime:",
          str(int((tot_time/3600)))+":"+str(int((tot_time%3600)/60))+":"
          +str(int((tot_time%3600)%60)) )